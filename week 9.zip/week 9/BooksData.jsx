const booksData = [
  {
    id: 1,
    title: "Full Stack Web Development ",
    author: "stephen roy",
    description: "Full-stack development is a multifaceted discipline within the realm of software engineering that encompasses the complete spectrum of designing, building, and maintaining software applications.",
    rating: 4.8,
  },
  {
    id: 2,
    title: "Deep Work",
    author: "Cal Newport",
    description: "Rules for focused success in a distracted world.",
    rating: 4.5,
  },
  {
    id: 3,
    title: "The Alchemist",
    author: "Paulo Coelho",
    description: "A philosophical story about following your dreams.",
    rating: 4.7,
  },
];

export default booksData;
